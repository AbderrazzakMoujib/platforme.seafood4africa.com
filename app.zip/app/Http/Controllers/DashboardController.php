<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\User;
use App\Models\Category;
use App\Models\Country;
use App\Models\Product;

class DashboardController extends Controller
{
    public function index()
    {
        $user = auth()->user();

        if ($user->role === 'admin') {
            return redirect()->route('dashboard.admin');
        }

        $products   = Product::where('user_id', $user->id)->get();
        $categories = Category::all();
        $countries  = Country::all();

        return view('dashboard.user', compact('products', 'categories', 'countries', 'user'));
    }

    public function adminIndex()
    {
        $products     = Product::all();
        $categories   = Category::all();
        $countries    = Country::all();
        $pendingUsers = User::where('status', 'pending')
                            ->where('role', '!=', 'admin')
                            ->with('country')
                            ->latest()
                            ->get();
        $pendingCount = $pendingUsers->count();

        return view('dashboard.admin', compact(
            'products', 'categories', 'countries', 'pendingUsers', 'pendingCount'
        ));
    }

    public function addAdmin(Request $request)
    {
        $request->validate([
            'name'     => 'required|string|max:255',
            'email'    => 'required|string|email|max:255|unique:users',
            'password' => 'required|string|min:8|confirmed',
        ]);

        User::create([
            'name'     => $request->name,
            'email'    => $request->email,
            'password' => bcrypt($request->password),
            'role'     => 'admin',
            'status'   => 'approved',
        ]);

        return redirect()->route('dashboard.admin')->with('success', 'Admin added successfully!');
    }

    public function deleteUser($id)
    {
        $user = User::find($id);

        if ($user && $user->id !== auth()->id()) {
            $user->delete();
            return redirect()->route('dashboard')->with('success', 'User deleted successfully!');
        }

        return redirect()->route('dashboard')->with('error', 'Cannot delete this user.');
    }

    public function addCategory(Request $request)
    {
        $request->validate([
            'name'  => 'required|string|max:255',
            'image' => 'nullable|image|mimes:jpg,jpeg,png,gif|max:2048',
            'icon'  => 'nullable|image|mimes:jpg,jpeg,png,gif|max:2048',
        ]);

        $imagePath = null;
        $iconPath  = null;

        if ($request->hasFile('image')) {
            $imagePath = $request->file('image')->store('category_images', 'public');
        }
        if ($request->hasFile('icon')) {
            $iconPath = $request->file('icon')->store('category_icons', 'public');
        }

        Category::create([
            'name'  => $request->name,
            'image' => $imagePath,
            'icon'  => $iconPath,
        ]);

        return redirect()->route('dashboard.admin')->with('success', 'Category added successfully!');
    }
}