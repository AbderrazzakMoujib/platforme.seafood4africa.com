<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Product;
use App\Models\Category;
use Illuminate\Support\Facades\Auth;

class ProductController extends Controller
{
    public function create()
    {
        $categories = Category::all();
        return view('dashboard.add-product', compact('categories'));
    }

    public function store(Request $request)
    {
        $request->validate([
            'title' => 'required|string|max:255',
            'description' => 'required|string',
            'image' => 'required|image|mimes:jpg,jpeg,png,gif|max:2048',
            'category_id' => 'required|exists:categories,id',
        ]);

        $imagePath = $request->file('image')->store('product_images', 'public');

        Product::create([
            'user_id' => Auth::id(),
            'title' => $request->title,
            'description' => $request->description,
            'image' => $imagePath,
            'category_id' => $request->category_id,
        ]);

        return redirect()->route('dashboard')->with('success', 'Product added successfully!');
    }

    public function destroy($id)
    {
        $product = Product::findOrFail($id);

        if (Auth::user()->isAdmin() || $product->user_id == Auth::id()) {
            $product->delete();
            return redirect()->route('dashboard')->with('success', 'Product deleted successfully!');
        }

        return redirect()->route('dashboard')->with('error', 'You do not have permission to delete this product.');
    }
    
    
    public function edit($id)
{
    $product = Product::findOrFail($id);
    $categories = Category::all();

    return view('dashboard.edit-product', compact('product', 'categories'));
}

public function update(Request $request, $id)
{
    $product = Product::findOrFail($id);

    $request->validate([
        'title' => 'required|string|max:255',
        'description' => 'required|string',
        'image' => 'nullable|image|mimes:jpg,jpeg,png,gif|max:2048',
        'category_id' => 'required|exists:categories,id',
    ]);

    $product->title = $request->title;
    $product->description = $request->description;
    $product->category_id = $request->category_id;

    if ($request->hasFile('image')) {
        $imagePath = $request->file('image')->store('product_images', 'public');
        $product->image = $imagePath;
    }

    $product->save();

    return redirect()->route('dashboard')->with('success', 'Product updated successfully!');
}
}
