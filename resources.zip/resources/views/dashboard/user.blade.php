<!doctype html>
<html lang="en">

<head>
        <meta charset="utf-8" />
        <title>Dashboard User</title>
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta content="Premium Multipurpose Admin & Dashboard Template" name="description" />
        <meta content="Themesdesign" name="author" />
        <!-- App favicon -->
        <link rel="shortcut icon" href="{{asset('assets1/images/favicon.ico')}}">

        <!-- datepicker -->
        <link href="{{asset('assets1/libs/air-datepicker/css/datepicker.min.css')}}" rel="stylesheet" type="text/css" />

        <!-- jvectormap -->
        <link href="{{asset('assets1/libs/jqvmap/jqvmap.min.css')}}" rel="stylesheet" />

        <!-- Bootstrap Css -->
        <link href="{{asset('assets1/css/bootstrap.min.css')}}" rel="stylesheet" type="text/css" />
        <!-- Icons Css -->
        <link href="{{asset('assets1/css/icons.min.css')}}" rel="stylesheet" type="text/css" />
        <!-- App Css-->
        <link href="{{asset('assets1/css/app.min.css')}}" rel="stylesheet" type="text/css" />

    </head>

    <body data-topbar="colored">

        <!-- Begin page -->
        <div id="layout-wrapper">
        <header id="page-topbar">
    <div class="navbar-header">
        <div class="d-flex">
            <!-- LOGO -->
            <div class="navbar-brand-box">
                <a href="{{route('home')}}" class="logo logo-dark">
                    <span class="logo-sm">
                        <img src="{{ asset('assets/images/logo/favicon.webp') }}"   width="30px">
                    </span>
                    <span class="logo-lg">
                        <img src="{{ asset('assets/images/logo/logo3.webp') }}" width="160px" >
                    </span>
                </a>

                <a href="{{route('home')}}" class="logo logo-light">
                    <span class="logo-sm">
                        <img src="{{ asset('assets/images/logo/favicon.webp') }}" width="30px" alt="" >
                    </span>
                    <span class="logo-lg">
                        <img src="{{ asset('assets/images/logo/logo2.webp') }}" alt="" width="160px" >
                    </span>
                </a>
            </div>

            <button type="button" class="btn btn-sm px-3 font-size-24 header-item waves-effect" id="vertical-menu-btn">
                <i class="mdi mdi-backburger"></i>
            </button>

            <!-- App Search-->
            <form class="app-search d-none d-lg-block">
                <div class="position-relative mt-3">
                    <input type="text" class="form-control" placeholder="Search...">
                    <span class="mdi mdi-magnify"></span>
                </div>
            </form>
        </div>

        <div class="d-flex">
            <div class="dropdown d-inline-block d-lg-none ms-2">
                <button type="button" class="btn header-item noti-icon waves-effect" id="page-header-search-dropdown" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                    <i class="mdi mdi-magnify"></i>
                </button>
                <div class="dropdown-menu dropdown-menu-lg dropdown-menu-right p-0" aria-labelledby="page-header-search-dropdown">
                    <form class="p-3">
                        <div class="form-group mt-3">
                            <div class="input-group">
                                <input type="text" class="form-control" placeholder="Search ..." aria-label="Recipient's username">
                                <div class="input-group-append">
                                    <button class="btn btn-primary" type="submit"><i class="mdi mdi-magnify"></i></button>
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
            </div>

            <div class="dropdown d-inline-block language-switch">
                <button type="button" class="btn header-item noti-icon" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                    <img id="header-lang-img" src="{{ asset('assets1/images/flags/us.jpg') }}" alt="Header Language" height="14">
                </button>
                <div class="dropdown-menu dropdown-menu-end">
                    <a href="javascript:void(0);" class="dropdown-item notify-item language" data-lang="sp">
                        <img src="{{ asset('assets1/images/flags/spain.jpg') }}" alt="user-image" class="me-2" height="12"> <span class="align-middle">Spanish</span>
                    </a>
                    <a href="javascript:void(0);" class="dropdown-item notify-item language" data-lang="gr">
                        <img src="{{ asset('assets1/images/flags/germany.jpg') }}" alt="user-image" class="me-2" height="12"> <span class="align-middle">German</span>
                    </a>
                    <a href="javascript:void(0);" class="dropdown-item notify-item language" data-lang="it">
                        <img src="{{ asset('assets1/images/flags/italy.jpg') }}" alt="user-image" class="me-2" height="12"> <span class="align-middle">Italian</span>
                    </a>
                    <a href="javascript:void(0);" class="dropdown-item notify-item language" data-lang="ru">
                        <img src="{{ asset('assets1/images/flags/russia.jpg') }}" alt="user-image" class="me-2" height="12"> <span class="align-middle">Russian</span>
                    </a>
                </div>
            </div>

      

            <!-- light dark btn -->
            <div class="dropdown d-none d-sm-inline-block">
                <button type="button" class="btn header-item" id="light-dark-mode">
                    <i class="mdi mdi-moon-waning-crescent align-middle fs-4"></i>
                </button>
            </div>

            <div class="dropdown d-inline-block">
                <button type="button" class="btn header-item user text-start d-flex align-items-center" id="page-header-user-dropdown" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                    @if(Auth::user()->profile_picture)
                        <img src="{{ asset('storage/' . Auth::user()->profile_picture) }}" alt="Logo" width="40px" class="rounded-circle" style="object-fit:cover;height:40px;">
                    @else
                        <div style="width:40px;height:40px;border-radius:50%;background:#3051d3;display:flex;align-items:center;justify-content:center;color:#fff;font-weight:700;font-size:16px;">
                            {{ strtoupper(substr(Auth::user()->name, 0, 1)) }}
                        </div>
                    @endif
                    <span class="d-none d-sm-inline-block ms-1">{{ Auth::user()->name }}</span>
                    <i class="mdi mdi-chevron-down d-none d-sm-inline-block"></i>
                </button>
                <div class="dropdown-menu dropdown-menu-end ">
                    <a class="dropdown-item" href="{{ route('profile.edit') }}">
                        <i class="mdi mdi-face-profile font-size-16 align-middle me-1"></i>
                        Profile
                    </a>
             
                    <div class="dropdown-divider"></div>
                    <form method="POST" action="{{ route('logout') }}">
                        @csrf
                        <a class="dropdown-item" href="#"
                            onclick="event.preventDefault(); this.closest('form').submit();">
                            <i class="mdi mdi-logout font-size-16 align-middle me-1"></i>
                            {{ __('Log Out') }}
                        </a>
                    </form>
                </div>
            </div>
        </div>
    </div>
</header>


            <!-- ========== Left Sidebar Start ========== -->
            <div class="vertical-menu">

                <div data-simplebar class="h-100">

                    <!--- Sidemenu -->
                    <div id="sidebar-menu">
                        <!-- Left Menu Start -->
                        <ul class="metismenu list-unstyled" id="side-menu">
                            <li class="menu-title">Menu</li>
                            <li>
                                <a href="{{route('dashboard')}}" class="waves-effect">
                                    <span>Dashboard</span>
                                </a>
                            </li>
                            <li>
                                <a href="javascript: void(0);" class="has-arrow waves-effect">
                                    <div class="d-inline-block icons-sm me-1"><i class="uim uim-comment-message"></i></div>
                                    <span>Products</span>
                                </a>
                                <ul class="sub-menu" aria-expanded="false">
                                    <li><a href="{{route('add_products_user')}}">Add Product</a></li>
                                </ul>
                            </li>
                            <li>
                                <a href="javascript: void(0);" class="has-arrow waves-effect">
                                    <div class="d-inline-block icons-sm me-1"><i class="uim uim-comment-message"></i></div>
                                    <span>Add Resources</span>
                                </a>
                                <ul class="sub-menu" aria-expanded="false">
                                <li><a href="{{ route('videos.create') }}">Add Video</a></li>
                                <li><a href="{{ route('pdfs.create') }}">Add PDF</a></li>
                                <li><a href="{{ route('images.create') }}">Add Image</a></li>
                            </ul>
                          
                            </li>

                            
                        </ul>
                    </div>
                    <!-- Sidebar -->
                </div>
            </div>
            <!-- Left Sidebar End -->

            <!-- ============================================================== -->
            <!-- Start right Content here -->
            <!-- ============================================================== -->
            <div class="main-content">

                <div class="page-content">
                    
                    <!-- Page-Title -->
                    <div class="page-title-box">
                        <div class="container-fluid">
                            <div class="row align-items-center">
                                <div class="col-md-8">
                                    <h4 class="page-title mb-1">Dashboard</h4>
                                    <ol class="breadcrumb m-0">
                                    <li class="breadcrumb-item active">Welcome to SeaFood4Africa Dashboard</li>
                                    </ol>
                                </div>
                      
                            </div>

                        </div>
                    </div>
                    <!-- end page title end breadcrumb -->

                    <div class="page-content-wrapper">
                        <div class="container-fluid">
                            <div class="row">
                                <div class="col-xl-4">
                                    <div class="card">
                                        <div class="card-body">
                                            <div class="d-flex align-items-center gap-3 mb-3">
                                                <!-- Company Logo -->
                                                <div style="width:64px;height:64px;border-radius:12px;overflow:hidden;border:2px solid rgba(48,81,211,0.2);background:rgba(48,81,211,0.05);flex-shrink:0;display:flex;align-items:center;justify-content:center;">
                                                    @if(Auth::user()->profile_picture)
                                                        <img src="{{ asset('storage/' . Auth::user()->profile_picture) }}" alt="Logo" style="width:100%;height:100%;object-fit:cover;">
                                                    @else
                                                        <i class="mdi mdi-domain" style="font-size:28px;color:#3051d3;"></i>
                                                    @endif
                                                </div>
                                                <div>
                                                    <h5 class="mb-1">{{ Auth::user()->raison_social ?? Auth::user()->name }}</h5>
                                                    <p class="text-muted mb-0" style="font-size:12px;">
                                                        @if(Auth::user()->country)
                                                            <i class="mdi mdi-earth me-1"></i>{{ Auth::user()->country->name }}
                                                        @endif
                                                        @if(Auth::user()->category)
                                                            &nbsp;·&nbsp;<i class="mdi mdi-tag-outline me-1"></i>{{ Auth::user()->category->name }}
                                                        @endif
                                                    </p>
                                                </div>
                                            </div>
                                            <p class="text-muted" style="font-size:13px;">Welcome to your SeaFood4Africa dashboard.</p>
                                            <a href="{{ route('profile.edit') }}" class="btn btn-primary btn-sm">Edit Profile <i class="mdi mdi-arrow-right ms-1"></i></a>
                                        </div>
                                    </div>
                                    <div class="card">
                                        <div class="card-body">
                                            <h5 class="header-title mb-4">Monthy sale Report</h5>
                                            <div class="d-flex">
                                                <div class="media-body flex-grow-1">
                                                    <p class="text-muted mb-2">This month Sale</p>
                                                    <h4>$ 13,425</h4>
                                                </div>
                                                <div dir="ltr" class="ms-2">
                                                    <input data-plugin="knob" data-width="56" data-height="56" data-linecap=round data-displayInput=false
                                                    data-fgColor="#3051d3" value="56" data-skin="tron" data-angleOffset="56"
                                                    data-readOnly=true data-thickness=".17" />
                                                </div>
                                            </div>
                                            <hr>
                                            <div class="d-flex">
                                                <div class="media-body flex-grow-1">
                                                    <p class="text-muted">Sale status</p>
                                                    <h5 class="mb-0"> + 12 % <span class="font-size-14 text-muted ms-1">From previous period</span></h5>
                                                </div>

                                                <div class="align-self-end ms-2">
                                                    <a href="#" class="btn btn-primary btn-sm">View more</a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
        
                                <div class="col-xl-8">
                                    <div class="card">
                                        <div class="card-body">
                                            <form class="form-inline float-end">
                                                <div class="input-group mb-3">
                                                    <input type="text" class="form-control form-control-sm datepicker-here" data-range="true"  data-multiple-dates-separator=" - " data-language="en" placeholder="Select Date" />
                                                    <div class="input-group-append">
                                                        <span class="input-group-text"><i class="far fa-calendar font-size-12"></i></span>
                                                    </div>
                                                </div>
                                            </form>
                                            <h5 class="header-title mb-4">Sales Report</h5>
                                            <div id="yearly-sale-chart" class="apex-charts"></div>
                                        </div>
                                    </div>
                                </div>
        
                            </div>
                            <!-- end row -->

                            <div class="row">
                                <div class="col-lg-4">
                                    <div class="card">
                                        <div class="card-header bg-transparent p-3">
                                            <h5 class="header-title mb-0">Sales Status</h5>
                                        </div>
                                        <ul class="list-group list-group-flush">
                                            <li class="list-group-item">
                                                <div class="d-flex my-2">
                                                    
                                                    <div class="media-body flex-grow-1">
                                                        <p class="text-muted mb-2">Number of Sales</p>
                                                        <h5 class="mb-0">1,625</h5>
                                                    </div>
                                                    <div class="icons-lg ms-2 align-self-center">
                                                        <i class="uim uim-layer-group"></i>
                                                    </div>
                                                </div>
                                            </li>
                                            <li class="list-group-item">
                                                <div class="d-flex my-2">
                                                    <div class="media-body flex-grow-1">
                                                        <p class="text-muted mb-2">Sales Revenue </p>
                                                        <h5 class="mb-0">$ 42,235</h5>
                                                    </div>
                                                    <div class="icons-lg ms-2 align-self-center">
                                                        <i class="uim uim-analytics"></i>
                                                    </div>
                                                </div>
                                            </li>
                                            <li class="list-group-item">
                                                <div class="d-flex my-2">
                                                    <div class="media-body flex-grow-1">
                                                        <p class="text-muted mb-2">Average Price</p>
                                                        <h5 class="mb-0">$ 14.56</h5>
                                                    </div>
                                                    <div class="icons-lg ms-2 align-self-center">
                                                        <i class="uim uim-ruler"></i>
                                                    </div>
                                                </div>
                                            </li>
                                            <li class="list-group-item">
                                                <div class="d-flex my-2">
                                                    <div class="media-body flex-grow-1">
                                                        <p class="text-muted mb-2">Product Sold</p>
                                                        <h5 class="mb-0">8,235</h5>
                                                    </div>
                                                    <div class="icons-lg ms-2 align-self-center">
                                                        <i class="uim uim-box"></i>
                                                    </div>
                                                </div>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                                <div class="col-lg-4">
                                    <div class="card">
                                        <div class="card-body">
                                            <h5 class="header-title mb-4">Social Source</h5>
                                            <div id="radial-chart" class="apex-charts"></div>

                                            <div class="text-center mt-3">
                                                <div class="row">
                                                    <div class="col-6">
                                                        <div>
                                                            <p class="text-muted"><i class="mdi mdi-circle text-primary me-1"></i> Facebook</p>
                                                            <h5>$ 1,625</h5>
                                                        </div>
                                                    </div>
                                                    <div class="col-6">
                                                        <div>
                                                            <p class="text-muted"><i class="mdi mdi-circle text-warning me-1"></i> Twitter</p>
                                                            <h5>$ 1,504</h5>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-lg-4">
                                    <div class="card">
                                        <div class="card-body">
                                            <h5 class="header-title">Recent Activity</h5>

                                            <div id="activity-chart" class="apex-charts"></div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <!-- end row -->

                            <div class="row">
                                <div class="col-lg-8">
                                    <div class="card">
                                        <div class="card-body">
                                            <div class="float-end ms-2">
                                                <a href="#">View all</a>
                                            </div>
                                            <h5 class="header-title mb-4">Latest Transaction</h5>

                                            <div class="table-responsive">
                                                <table class="table table-centered table-hover mb-0">
                                                    <thead>
                                                        <tr>
                                                            <th scope="col">Transaction ID</th>
                                                            <th scope="col">Name</th>
                                                            <th scope="col">Date</th>
                                                            <th scope="col">status</th>
                                                            <th scope="col">Amount</th>
                                                            <th scope="col">Action</th>
                                                        </tr>
                                                    </thead>
                                                    <tbody>
                                                        <tr>
                                                            <th scope="row">
                                                                <a href="#"># XO1345</a>
                                                            </th>
                                                            <td>Danny Johnson</td>
                                                            <td>26 Jan</td>
                                                            <td>
                                                                <div class="badge bg-primary-subtle text-primary">Confirm</div>
                                                            </td>
                                                            <td>$124</td>
                                                            <td>
                                                                <div class="btn-group" role="group">
                                                                    <button type="button" class="btn btn-outline-secondary btn-sm" data-toggle="tooltip" data-placement="top" title="View">
                                                                        <i class="mdi mdi-eye"></i>
                                                                    </button>
                                                                    <button type="button" class="btn btn-outline-secondary btn-sm" data-toggle="tooltip" data-placement="top" title="Edit">
                                                                        <i class="mdi mdi-pencil"></i>
                                                                    </button>
                                                                    <button type="button" class="btn btn-outline-secondary btn-sm" data-toggle="tooltip" data-placement="top" title="Delete">
                                                                        <i class="mdi mdi-trash-can"></i>
                                                                    </button>
                                                                </div>
                                                            </td>
                                                        </tr>
                                                        <tr>
                                                            <th scope="row">
                                                                <a href="#"># XO1346</a>
                                                            </th>
                                                            <td>Alvin Newton</td>
                                                            <td>21 Jan</td>
                                                            <td>
                                                                <div class="badge bg-warning-subtle text-warning">Pending</div>
                                                            </td>
                                                            <td>$112</td>
                                                            <td>
                                                                <div class="btn-group" role="group">
                                                                    <button type="button" class="btn btn-outline-secondary btn-sm" data-toggle="tooltip" data-placement="top" title="View">
                                                                        <i class="mdi mdi-eye"></i>
                                                                    </button>
                                                                    <button type="button" class="btn btn-outline-secondary btn-sm" data-toggle="tooltip" data-placement="top" title="Edit">
                                                                        <i class="mdi mdi-pencil"></i>
                                                                    </button>
                                                                    <button type="button" class="btn btn-outline-secondary btn-sm" data-toggle="tooltip" data-placement="top" title="Delete">
                                                                        <i class="mdi mdi-trash-can"></i>
                                                                    </button>
                                                                </div>
                                                            </td>
                                                        </tr>
                                                        <tr>
                                                            <th scope="row">
                                                                <a href="#"># XO1347</a>
                                                            </th>
                                                            <td>Bennie Perez</td>
                                                            <td>15 Jan</td>
                                                            <td>
                                                                <div class="badge bg-primary-subtle text-primary">Confirm</div>
                                                            </td>
                                                            <td>$106</td>
                                                            <td>
                                                                <div class="btn-group" role="group">
                                                                    <button type="button" class="btn btn-outline-secondary btn-sm" data-toggle="tooltip" data-placement="top" title="View">
                                                                        <i class="mdi mdi-eye"></i>
                                                                    </button>
                                                                    <button type="button" class="btn btn-outline-secondary btn-sm" data-toggle="tooltip" data-placement="top" title="Edit">
                                                                        <i class="mdi mdi-pencil"></i>
                                                                    </button>
                                                                    <button type="button" class="btn btn-outline-secondary btn-sm" data-toggle="tooltip" data-placement="top" title="Delete">
                                                                        <i class="mdi mdi-trash-can"></i>
                                                                    </button>
                                                                </div>
                                                            </td>
                                                        </tr>
                                                        <tr>
                                                            <th scope="row">
                                                                <a href="#"># XO1348</a>
                                                            </th>
                                                            <td>Steven Kwon</td>
                                                            <td>11 Jan</td>
                                                            <td>
                                                                <div class="badge bg-primary-subtle text-primary">Confirm</div>
                                                            </td>
                                                            <td>$115</td>
                                                            <td>
                                                                <div class="btn-group" role="group">
                                                                    <button type="button" class="btn btn-outline-secondary btn-sm" data-toggle="tooltip" data-placement="top" title="View">
                                                                        <i class="mdi mdi-eye"></i>
                                                                    </button>
                                                                    <button type="button" class="btn btn-outline-secondary btn-sm" data-toggle="tooltip" data-placement="top" title="Edit">
                                                                        <i class="mdi mdi-pencil"></i>
                                                                    </button>
                                                                    <button type="button" class="btn btn-outline-secondary btn-sm" data-toggle="tooltip" data-placement="top" title="Delete">
                                                                        <i class="mdi mdi-trash-can"></i>
                                                                    </button>
                                                                </div>
                                                            </td>
                                                        </tr>
                                                        <tr>
                                                            <th scope="row">
                                                                <a href="#"># XO1349</a>
                                                            </th>
                                                            <td>Bryan Roark</td>
                                                            <td>08 Jan</td>
                                                            <td>
                                                                <div class="badge badge-soft-danger">Cancel</div>
                                                            </td>
                                                            <td>$105</td>
                                                            <td>
                                                                <div class="btn-group" role="group">
                                                                    <button type="button" class="btn btn-outline-secondary btn-sm" data-toggle="tooltip" data-placement="top" title="View">
                                                                        <i class="mdi mdi-eye"></i>
                                                                    </button>
                                                                    <button type="button" class="btn btn-outline-secondary btn-sm" data-toggle="tooltip" data-placement="top" title="Edit">
                                                                        <i class="mdi mdi-pencil"></i>
                                                                    </button>
                                                                    <button type="button" class="btn btn-outline-secondary btn-sm" data-toggle="tooltip" data-placement="top" title="Delete">
                                                                        <i class="mdi mdi-trash-can"></i>
                                                                    </button>
                                                                </div>
                                                            </td>
                                                        </tr>
                                                    </tbody>
                                                </table>
                                            </div>

                                            <div class="mt-4">
                                                <ul class="pagination pagination-rounded justify-content-center mb-0">
                                                    <li class="page-item disabled">
                                                        <a class="page-link" href="#" aria-label="Previous">
                                                            <i class="mdi mdi-chevron-left"></i>
                                                        </a>
                                                    </li>
                                                    <li class="page-item"><a class="page-link me-2" href="#">1</a></li>
                                                    <li class="page-item active"><a class="page-link me-2" href="#">2</a></li>
                                                    <li class="page-item"><a class="page-link me-2" href="#">3</a></li>
                                                    <li class="page-item"><a class="page-link me-2" href="#">4</a></li>
                                                    <li class="page-item">
                                                        <a class="page-link me-2" href="#" aria-label="Next">
                                                            <i class="mdi mdi-chevron-right"></i>
                                                        </a>
                                                    </li>
                                                </ul>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                
                                <div class="col-lg-4">
                                    <div class="card">
                                        <div class="card-body">
                                            <h5 class="header-title mb-4">Revenue by Location</h5>

                                            <div id="usa-map"  style="height: 150px" class="mb-5"></div>

                                            <div class="table-responsive">
                                                <table class="table table-centered">
                                                    <tbody>
                                                        <tr>
                                                            <th scope="row">California</th>
                                                            <td>$ 8,257</td>
                                                            <td>
                                                                <div dir="ltr" class="ms-2">
                                                                    <input data-plugin="knob" data-width="36" data-height="36" data-linecap=round data-displayInput=false
                                                                    data-fgColor="#3051d3" value="56" data-skin="tron" data-angleOffset="36"
                                                                    data-readOnly=true data-thickness=".2" />
                                                                </div>
                                                            </td>
                                                        </tr>
                                                        <tr>
                                                            <th scope="row">New York</th>
                                                            <td>$ 7,253</td>
                                                            <td>
                                                                <div dir="ltr" class="ms-2">
                                                                    <input data-plugin="knob" data-width="36" data-height="36" data-linecap=round data-displayInput=false
                                                                    data-fgColor="#3051d3" value="42" data-skin="tron" data-angleOffset="36"
                                                                    data-readOnly=true data-thickness=".2" />
                                                                </div>
                                                            </td>
                                                        </tr>
                                                    </tbody>
                                                </table>

                                                <div class="text-center">
                                                    <a href="#" class="btn btn-primary btn-sm">View more <i class="mdi mdi-arrow-right ms-1"></i></a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <!-- end row -->

                        </div> <!-- container-fluid -->
                    </div>
                    <!-- end page-content-wrapper -->
                </div>
                <!-- End Page-content -->

                
                <footer class="footer">
                    <div class="container-fluid">
                        <div class="row">
                            <div class="col-sm-6">
                                2024 © Fenip.
                            </div>
                            <div class="col-sm-6">
                                <div class="text-sm-end d-none d-sm-block">
                                    Crafted with <i class="mdi mdi-heart text-danger"></i> by Smart Expos
                                </div>
                            </div>
                        </div>
                    </div>
                </footer>
            </div>
            <!-- end main content-->

        </div>
        <!-- END layout-wrapper -->

     

        <!-- Right bar overlay-->
        <div class="rightbar-overlay"></div>

        <!-- JAVASCRIPT -->
        <script src="{{asset('assets1/libs/jquery/jquery.min.js')}}"></script>
        <script src="{{asset('assets1/libs/bootstrap/js/bootstrap.bundle.min.js')}}"></script>
        <script src="{{asset('assets1/libs/metismenu/metisMenu.min.js')}}"></script>
        <script src="{{asset('assets1/libs/simplebar/simplebar.min.js')}}"></script>
        <script src="{{asset('assets1/libs/node-waves/waves.min.js')}}"></script>

        <script src="../../../../../unicons.iconscout.com/release/v2.0.1/script/monochrome/bundle.js"></script>

        <!-- datepicker -->
        <script src="{{asset('assets1/libs/air-datepicker/js/datepicker.min.js')}}"></script>
        <script src="{{asset('assets1/libs/air-datepicker/js/i18n/datepicker.en.js')}}"></script>

        <!-- apexcharts -->
        <script src="{{asset('assets1/libs/apexcharts/apexcharts.min.js')}}"></script>

        <script src="{{asset('assets1/libs/jquery-knob/jquery.knob.min.js')}}"></script> 

        <!-- Jq vector map -->
        <script src="{{asset('assets1/libs/jqvmap/jquery.vmap.min.js')}}"></script>
        <script src="{{asset('assets1/libs/jqvmap/maps/jquery.vmap.usa.js')}}"></script>

        <script src="{{asset('assets1/js/pages/dashboard.init.js')}}"></script>

        <script src="{{asset('assets1/js/app.js')}}"></script>

    </body>
</html>
